//console.log("js connected");
$(document).ready(function () {
  $("#resetform").click(function () {
    $("#form")[0].reset();
  });
  $("#resetform").click(function () {
    $(".form")[0].reset();
  });

  $("Reset").click(function () {
    $("#form")[0].reset();
  });
});
