<?php

$servername = "localhost";
$username = "id18590966_root";
$password = "3ye5XLMZ}7_ffUvJ";
$database = "id18590966_management";

$conn = mysqli_connect($servername, $username, $password, $database);
if(!$conn){
    echo 'Not connected to database';
}
if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
}

?>